def classFactory(iface):
    from .easyfillet import EasyFillet
    return EasyFillet(iface)
